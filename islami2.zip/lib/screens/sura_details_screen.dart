import 'package:flutter/material.dart';
import 'package:islami/screens/models/quran_resources.dart';
import 'package:islami/utils/app_assets.dart';
import 'package:islami/utils/app_colors.dart';
import 'package:islami/utils/app_styles.dart';


class SuraDetailsScreen extends StatelessWidget {
  const SuraDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    var args = ModalRoute.of(context)?.settings.arguments as int ;
    return Scaffold(
      appBar: AppBar(
        title: Text(QuranResources.englishQuranSuras[args],style: AppStyles.bold20Gold,),

      ),
      backgroundColor: AppColors.backgroundColor,
      body: Padding(
        padding:  EdgeInsets.symmetric(horizontal: width * 0.04 ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Image.asset(AppAssets.left),
                Text(QuranResources.arabicQuranSuras[args],style: AppStyles.bold20Gold,),
                Image.asset(AppAssets.right)


              ],
            ),
            Expanded(child: Container()),
            Image.asset(AppAssets.decoration)
          ],
        ),
      ),
    );
  }
}
