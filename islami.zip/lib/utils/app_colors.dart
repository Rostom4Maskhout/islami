import 'package:flutter/material.dart';


class AppColors {
  static const backgroundColor = Color(0xFF202020);
  static const backbgColor = Color(0x99202020);
  static const goldColor = Color(0xFFFFD482);
  static const primaryColor = Color(0xFFE2BE7F);

}

