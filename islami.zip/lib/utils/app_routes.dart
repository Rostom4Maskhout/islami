class AppRoutes {
  static const String onBoardingRoute = 'onBoarding_screen';
  static const String homeRoute = 'home_screen';
  static const String suraDetailsRoute = 'sura_details_screen';



}