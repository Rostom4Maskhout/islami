import 'package:flutter/material.dart';


class TimeTab extends StatelessWidget {
  const TimeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
